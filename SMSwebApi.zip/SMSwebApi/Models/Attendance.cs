﻿using System.ComponentModel.DataAnnotations;

namespace SMSwebApi.Models
{
    public class Attendance
    {

        [Key]
        public int Id { get; set; }
        [Required]
        public int StudentId { get; set; }
        [Required]
        public int AttendanceStatus { get; set; }
        [Required]
        public int ClassroomId { get; set; }
        public DateTime AttendanceDate { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

    }
}
