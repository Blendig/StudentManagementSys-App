﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SMSwebApi.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string FirstName { get; set; } = "";
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string LastName { get; set; } = "";
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string Email { get; set; } = "";
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string Password { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Address { get; set; } = "";
        public string City { get; set; } = "";
        [Required]
        public int Role { get; set; }
        public string Privileges { get; set; } = "";
        public string Designation { get; set; } = "";
        public string AvatarURL { get; set; } = "";
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

    }
}
