﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SMSwebApi.Models
{
    public class Student
    {

        [Key]
        public int Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string FirstName { get; set; } = "";
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string LastName { get; set; } = "";
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string Email { get; set; } = "";

        public DateTime DOB { get; set; }
        public string Gender { get; set; } = "";
        public string City { get; set; } = "";
        public int ClassroomId { get; set; }
        //public Object Courses { get; set; }
        public string AvatarURL { get; set; } = "";
        public DateTime CreatedAt { get; set; }
        public DateTime LastUpdatedAt { get; set; }

    }
}
