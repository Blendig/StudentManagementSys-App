﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SMSwebApi.Models
{
    public class Announcement
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(250)")]
        public string Title { get; set; } = "";
        [Required]
        public string Description { get; set; } = "";
        public string Attachments { get; set; } = "";
        [Required]
        [Column(TypeName = "nvarchar(250)")]
        public string Audience { get; set; } = "";
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

    }
}
