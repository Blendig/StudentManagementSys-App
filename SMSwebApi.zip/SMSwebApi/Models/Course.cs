﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SMSwebApi.Models
{
    public class Course
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int InstructorId { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string CourseName { get; set; } = "";
        public string Duration { get; set; } = "";
        public string Description { get; set; } = "";
        public string Attachments { get; set; } = "";
        public DateTime createdAt { get; set; } = DateTime.Now;
        public DateTime updatedAt { get; set; } = DateTime.Now;

    }
}
