﻿using Microsoft.EntityFrameworkCore;
using SMSwebApi.Models;

namespace SMSwebApi.Data
{
    public class DataContext:DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }
        public DbSet<SMSwebApi.Models.Announcement> Announcement { get; set; }
        public DbSet<SMSwebApi.Models.Assignment> Assignment { get; set; }
        public DbSet<SMSwebApi.Models.Attendance> Attendance { get; set; }
        public DbSet<SMSwebApi.Models.Classroom> Classroom { get; set; }
        public DbSet<SMSwebApi.Models.Course> Course { get; set; }
        public DbSet<SMSwebApi.Models.Student> Student { get; set; }
        public DbSet<SMSwebApi.Models.User> User { get; set; }
        public DbSet<SMSwebApi.Models.Role> Role { get; set; }

    }
}
