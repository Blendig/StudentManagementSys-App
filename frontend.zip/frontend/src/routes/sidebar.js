/**
 * ⚠ These are used just to render the Sidebar!
 * You can include any link here, local or external.
 *
 * If you're looking to actual Router routes, go to
 * `routes/index.js`
 */
const routes = [
  {
    path: '/app/dashboard', // the url
    icon: 'HomeIcon', // the component being exported from icons/index.js
    name: 'Dashboard', // name that appear in Sidebar
  },
  {
    path: '/app/users',
    icon: 'OutlinePersonIcon',
    name: 'Users',
    routes:[
      {
        path: '/app/users/list-user',
        name: 'List Users',
      },
      {
        path: '/app/users/add-user',
        name: 'Add',
      },
      
      
    ]
  },
  {
    path: '/app/students',
    icon: 'PeopleIcon',
    name: 'Students',
    routes:[
      {
        path: '/app/students/list-students',
        name: 'List Students',
      },
      {
        path: '/app/students/add-student',
        name: 'Add',
      },
     
      
    ]
  },
  {
    path: '/app/classroom',
    icon: 'FormsIcon',
    name: 'Classrooms',
    routes:[
      {
        path: '/app/classroom/list-classroom',
        name: 'List Classrooms',
      },
      {
        path: '/app/classroom/add-classroom',
        name: 'Add',
      },
    
      
    ]
  },
  {
    path: '/app/courses',
    icon: 'FormsIcon',
    name: 'Courses',
    routes:[
      {
        path: '/app/courses/list-course',
        name: 'List course',
      },
      {
        path: '/app/courses/add-course',
        name: 'Add',
      },
      
    ]
  },
 
  {
    path: '/app/settings',
    icon: 'OutlineCogIcon',
    name: 'Settings',
  },
  {
    path: '/app/assignments',
    icon: 'EditIcon',
    name: 'Assignments',
    routes:[
      {
        path: '/app/assignments/list-assignments',
        name: 'List assignments',
      },
      {
        path: '/app/assignments/add-assignment',
        name: 'Add',
      }
     
      
    ]
  },
  {
    path: '/app/attendance',
    icon: 'FormsIcon',
    name: 'Attendance',
    routes:[
      {
        path: '/app/attendance/list-attendance',
        name: 'List attendance',
      },
      {
        path: '/app/attendance/add-attendance',
        name: 'Add',
      },
   
      
    ]
  },
  {
    path: '/app/announcement',
    icon: 'BellIcon',
    name: 'Announcements',
    routes:[
      {
        path: '/app/announcement/list-announcements',
        name: 'List announcement',
      },
      {
        path: '/app/announcement/add-announcement',
        name: 'Add',
      },
     
      
    ]
  },
  /*
  {
    path: '/app/forms',
    icon: 'FormsIcon',
    name: 'Forms',
  },

  {
    path: '/app/cards',
    icon: 'CardsIcon',
    name: 'Cards',
  },
  {
    path: '/app/charts',
    icon: 'ChartsIcon',
    name: 'Charts',
  },
  {
    path: '/app/buttons',
    icon: 'ButtonsIcon',
    name: 'Buttons',
  },
  {
    path: '/app/modals',
    icon: 'ModalsIcon',
    name: 'Modals',
  },
  {
    path: '/app/tables',
    icon: 'TablesIcon',
    name: 'Tables',
  },
  {
    icon: 'PagesIcon',
    name: 'Pages',
    routes: [
      // submenu
      {
        path: '/login',
        name: 'Login',
      },
      {
        path: '/create-account',
        name: 'Create account',
      },
      {
        path: '/forgot-password',
        name: 'Forgot password',
      },
      {
        path: '/app/404',
        name: '404',
      },
      {
        path: '/app/blank',
        name: 'Blank',
      },
    ],
  },*/
]

export default routes
