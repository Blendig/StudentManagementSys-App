

const studentRoutes=[
    {
      path: '/app/dashboard', 
      icon: 'HomeIcon',
      name: 'Dashboard', 
    },
    {
      path: '/app/courses',
      icon: 'PeopleIcon',
      name: 'Courses',
    
    },
  
    {
      path: '/app/assignments',
      icon: 'EditIcon',
      name: 'Assignments',
  
    },
    {
      path: '/app/announcements',
      icon: 'BellIcon',
      name: 'Announcements',
  
    },
     {
      path: '/app/attendance',
      icon: 'FormsIcon',
      name: 'Attendance',
  
    },
    {
        path: '/app/settings',
        icon: 'OutlineCogIcon',
        name: 'Settings',
    
      },
  ]
  export default studentRoutes
  