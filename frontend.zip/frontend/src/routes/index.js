import { lazy } from 'react'

// use lazy for better code splitting, a.k.a. load faster
const Dashboard = lazy(() => import('../pages/Dashboard'))
const Forms = lazy(() => import('../pages/Forms'))
const Cards = lazy(() => import('../pages/Cards'))
const Charts = lazy(() => import('../pages/Charts'))
const Buttons = lazy(() => import('../pages/Buttons'))
const Modals = lazy(() => import('../pages/Modals'))
const Tables = lazy(() => import('../pages/Tables'))
const Page404 = lazy(() => import('../pages/404'))
const Blank = lazy(() => import('../pages/Blank'))
const Student = lazy(() => import('../pages/Student'))
const AddStudent = lazy(() => import('../pages/student/AddStudent'))
const ListStudents = lazy(() => import('../pages/student/ListStudents'))
const EditStudent = lazy(() => import('../pages/student/EditStudent'))
const AddClassroom = lazy(() => import('../pages/classroom/AddClassroom'))
const EditClassroom = lazy(() => import('../pages/classroom/EditClassroom'))
const ListClassroom = lazy(() => import('../pages/classroom/ListClassroom'))
//courses
const ListCourses = lazy(() => import('../pages/courses/ListCourse'))
const EditCourse = lazy(() => import('../pages/courses/EditCourse'))
const AddCourse = lazy(() => import('../pages/courses/AddCourse'))
const ViewCourseDetail = lazy(() => import('../pages/courses/ViewCourseDetail'))

//user
const AddUser = lazy(() => import('../pages/user/AddUser'))
const ListUser = lazy(() => import('../pages/user/ListUser'))
const UserDetailView =lazy(()=>import('../pages/user/UserDetail'))
const EditUser =lazy(()=>import('../pages/user/EditUser'))

//settings
const Settings = lazy(() => import('../pages/Settings'))
//assignments
const AddAssignment = lazy(() => import('../pages/assignments/AddAssignment'))
const ListAssignment = lazy(() => import('../pages/assignments/ListAssignments'))
const EditAssignment = lazy(() => import('../pages/assignments/EditAssignment'))
const ViewAssignmentDetail = lazy(() => import('../pages/assignments/ViewAssignmentDetail'))


//announcement
const AddAnnouncement = lazy(() => import('../pages/announcement/AddAnnouncement'))
const ListAnnouncement = lazy(() => import('../pages/announcement/ListAnnouncement'))
const EditAnnouncement = lazy(() => import('../pages/announcement/EditAnnouncement'))
const ViewAnnouncement = lazy(() => import('../pages/announcement/ViewAnnouncementDetail'))

//attendance
const AddAttendance = lazy(() => import('../pages/attendance/AddAttendance'))
const ListAttendance =lazy(()=>import('../pages/attendance/ListAttendance')) 
const AttendanceDetailCard =lazy(()=>import('../pages/attendance/AttendanceDetailCard')) 
const EditAttendanceSheet =lazy(()=>import('../pages/attendance/EditAttendance')) 




/**
 * ⚠ These are internal routes!
 * They will be rendered inside the app, using the default `containers/Layout`.
 * If you want to add a route to, let's say, a landing page, you should add
 * it to the `App`'s router, exactly like `Login`, `CreateAccount` and other pages
 * are routed.
 *
 * If you're looking for the links rendered in the SidebarContent, go to
 * `routes/sidebar.js`
 */
const routes = [
  {
    path: '/dashboard', // the url
    component: Dashboard, // view rendered
  },
  {
    path: '/users/add-user',
    component: AddUser,
  },
  {
    path: '/users/list-user',
    component: ListUser,
  },
  {
    path: '/users/edit/:id',
    component: EditUser,
  },
  {
    path: '/users/:id',
    component: UserDetailView,
  },
  {
    path: '/students/list-students',
    component: ListStudents,
  },
  {
    path: '/students/add-student',
    component: AddStudent,
  },
  {
    path: '/student/edit/:id',
    component: EditStudent,
  },
  {
    path: '/classroom/add-classroom',
    component: AddClassroom,
  },
  {
    path: '/classroom/edit/:id',
    component: EditClassroom,
  },
  {
    path: '/classroom/list-classroom',
    component: ListClassroom,
  },
  {
    path: '/courses/add-course',
    component: AddCourse,
  },
  {
    path: '/courses/edit/:id',
    component: EditCourse,
  },
  {
    path: '/courses/list-course',
    component: ListCourses,
  },
  {
    path: '/courses/view/:id',
    component: ViewCourseDetail,
  },
  {
    path: '/settings',
    component: Settings,
  },
  //assignment
  {
    path: '/assignments/add-assignment',
    component: AddAssignment,
  },
  {
    path: '/assignments/list-assignments',
    component: ListAssignment,
  }, {
    path: '/assignments/edit/:id',
    component: EditAssignment,
  },
  //announcemnt
   {
    path: '/announcement/edit/:id',
    component: EditAnnouncement,
  },
  {
    path: '/announcement/view/:id',
    component: ViewAnnouncement,
  },
  {
    path: '/announcement/list-announcements',
    component: ListAnnouncement,
  },
  {
    path: '/announcement/add-announcement',
    component: AddAnnouncement,
  },

//attendance
{
  path:'/attendance/add-attendance',
  component:AddAttendance,
},
{
  path:'/attendance/list-attendance',
  component:ListAttendance,
},
{
  path:'/attendance/:id',
  component:AttendanceDetailCard,
},

{
  path:'/attendance/edit/:attendanceId',
  component:EditAttendanceSheet,
},

//student routes
{
  path:'/attendance',
  component:ListAttendance,
},
{
  path: '/announcements',
  component: ListAnnouncement,
},
{
  path: '/courses',
  component: ListCourses,
},
{
  path: '/assignments',
  component: ListAssignment,
},
{
  path: '/assignments/view/:id',
  component: ViewAssignmentDetail,
},
/*
  {
    path: '/forms',
    component: Forms,
  },
  {
    path: '/cards',
    component: Cards,
  },
  {
    path: '/charts',
    component: Charts,
  },
  {
    path: '/buttons',
    component: Buttons,
  },
  {
    path: '/modals',
    component: Modals,
  },
  {
    path: '/tables',
    component: Tables,
  },
  {
    path: '/404',
    component: Page404,
  },
  {
    path: '/blank',
    component: Blank,
  },
  */
]

export default routes
