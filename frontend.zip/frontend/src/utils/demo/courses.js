const courses = [
    {
        name: 'Artificial Intelligence',
        duration: '28 hr',
        description: 'lorem ipsum dolor sit amet',
        instructor: 'John doe',
        timetable: 'file.pdf',
        amount:'4,535'

    },
    {
        name: 'Data Science',
        duration: '51 hr',
        description: 'lorem ipsum dolor sit amet',
        instructor: 'Mark Johnson',
        timetable: 'file.pdf',
        amount:'6,789'
    },
    {
        name: 'Computer Science (intro)',
        duration: '38 hr',
        description: 'lorem ipsum dolor sit amet',
        instructor: 'Dora Wood',
        timetable: 'file.pdf',
        amount:'2,340'
    },
    {
        name: 'Business Administration',
        duration: '3 yrs',
        description: 'lorem ipsum dolor sit amet',
        instructor: 'Chris Pine',
        timetable: 'file.pdf',
        amount:'56,000'
    },
]
export default courses