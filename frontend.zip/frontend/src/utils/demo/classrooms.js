const classrooms =[
    {
        name:'Accounts class',
        size:'25',
        rules:'Lorem ipsum dolor sit amet',
        status: 'primary',

    },
    {
        name:'Tech',
        size:'30',
        rules:'Lorem ipsum dolor sit amet',
        status: 'success',
    },
    {
        name:'Science',
        size:'15',
        rules:'Lorem ipsum dolor sit amet',
        status: 'warning',

    },
    {
        name:'Maths',
        size:'35',
        rules:'Lorem ipsum dolor sit amet',
        status: 'primary',

    },
    {
        name:'Engineering',
        size:'15',
        rules:'Lorem ipsum dolor sit amet',
        status: 'warning',

    },
    {
        name:'Class',
        size:'25',
        rules:'Lorem ipsum dolor sit amet',
        status: 'primary',

    },
    {
        name:'Class',
        size:'25',
        rules:'Lorem ipsum dolor sit amet',
        status: 'danger',

    },
    {
        name:'Class',
        size:'25',
        rules:'Lorem ipsum dolor sit amet',
        status: 'primary',

    },

];
export default classrooms;