const assignments =[
    {
        id:'1',
        title:'lorem ipsum dolor sit amet',
        createdBy:'John doe',
        attachment:'',
        duration:'30min',
        submitiondate: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
        date: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
    },
    {
        id:'2',
        title:'lorem ipsum dolor sit amet',
        createdBy:'Fay',
        attachment:'',
        duration:'30min',
        submitiondate: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
        date: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
    },
    {
        id:'3',
        title:'lorem ipsum dolor sit amet',
        createdBy:'Trey',
        attachment:'',
        duration:'30min',
        submitiondate: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
        date: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
    },
    {
        id:'4',
        title:'lorem ipsum dolor sit amet',
        createdBy:'Paul Walker',
        attachment:'',
        duration:'30min',
        submitiondate: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
        date: 'Fri Nov 29 2019 10:43:17 GMT-0300 (Brasilia Standard Time)',
    },

]
export default assignments