const attendanceData = [
    {
        id:'001',
        student: {id:'100',name:'Jon doe'},
        classroom:'class b',
        attendance: [
            { date: '1/02/2023', status: 'y' }
            , { date: '1/02/2023', status: 'y' },
            { date: '1/02/2023', status: 'y' }]
    },
    {
        id:'002',
        student: {id:'101',name:'Fay jones'},
        classroom:'class a',
        attendance: [
            { date: '1/02/2023', status: 'n' }
            , { date: '1/02/2023', status: 'y' },
            { date: '1/02/2023', status: 'n' }]
    },
    {
        id:'003',
        student: {id:'102',name:'Mo ali'},
        classroom:'class a',
        attendance: [
            { date: '1/02/2023', status: 'y' }
            , { date: '1/02/2023', status: 'y' },
            { date: '1/02/2023', status: 'n' }]
    },
    {
        id:'004',
        student: {id:'104',name:'Jack conor'},
        classroom:'class c',
        attendance: [
            { date: '1/02/2023', status: 'n' }
            , { date: '1/02/2023', status: 'y' },
            { date: '1/02/2023', status: 'n' }]
    },
]
export default attendanceData