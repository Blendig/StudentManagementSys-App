import React, { useEffect, useState, useContext, createContext } from 'react';
import axiosInstance from '../config/axios.config'

//import allowedRoutesForRole from './allowedRoutesForRole'
//------------------------------------------------
export const authContext = createContext();

export function ProvideAuth({ children }) {
    const auth = useProvideAuth();
    return <authContext.Provider value={auth}>{children}</authContext.Provider>
}

export const useAuth = () => {
    return useContext(authContext)
}

const mockUserAccount ={
    firstName:'jon',
    lastName:'doe',
    email:'jondoe@gmail.com',
    role:1
}
function useProvideAuth() {


    const [user, setUser] = useState(mockUserAccount);
    const [errors, setErrors] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [authorizedRoutes, setAuthorizedRoutes] = useState([])
    //useEffect
    useEffect(() => {
        verifyUser()
    }, [])
    //add signin function
    const signout = () => {
        return axiosInstance.post('api/user/logout')
            .then(res => {
               // redirect
            })
    }

    const verifyUser = () => {
        setErrors([])
        setIsLoading(true)
        axiosInstance.post(`api/user/verify`)
            .then(res => {
                setIsLoading(false)
                if (res.status === 200) {
                    const user = res.data.user;
                    user['role'] = user.level.toLowerCase()
                    setUser(user)
                }

            }).catch(error => {
                setErrors(['operation failed!'])
                setIsLoading(false)
            })
    }

    //return user object and auth methods
    return {
        user,
        signout,
        errors,
        isLoading
    }
}