import React, { useState } from 'react'

import PageTitle from './Typography/PageTitle'
import { Modal, ModalHeader, ModalBody, ModalFooter, Button } from '@windmill/react-ui'

function AppModal({open,close,header,func,acceptBtnText,cancelBtnText,children}) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  function onAccept(id) {
   
    return func(id)
  }

  return (
    <>
    
      <Modal isOpen={open} onClose={close}>
        <ModalHeader>{header}</ModalHeader>
        <ModalBody>
         {children}
        </ModalBody>
        <ModalFooter>
    
          <div className="hidden sm:block">
            <Button layout="outline" size='large' onClick={close}>
              {cancelBtnText || 'cancel'}
            </Button>
          </div>
        
          <div className="hidden sm:block">
            <Button block size="large" onClick={onAccept}>
              {acceptBtnText || 'Accept'}
            </Button>
          </div>
        </ModalFooter>
      </Modal>
    </>
  )
}

export default AppModal
