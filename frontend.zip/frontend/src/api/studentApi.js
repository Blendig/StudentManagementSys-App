import axios from "../config/axios.config";
const studentApi ={
    create:(data)=>{
        return axios.post(`/Students`,data)
    },
    fetchAll:()=>{
        return axios.get(`/Students`)
    },
    fetchOne:(id)=>{
        return axios.get(`/Students/${id}`)
    },
    edit:(id,data)=>{
        return axios.put(`/Students/${id}`/data)
    },
    delete:(id)=>{
        return axios.delete(`/Students/${id}`)
    }
}
export default studentApi;