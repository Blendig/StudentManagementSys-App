import axios from "../config/axios.config";
const classroomApi ={
    create:(data)=>{
        return axios.post()
    },
    fetchAll:()=>{
        return axios.get()
    },
    fetchOne:()=>{
        return axios.get()
    },
    edit:()=>{
        return axios.put()
    },
    delete:()=>{
        return axios .delete()
    }
}
export default classroomApi;