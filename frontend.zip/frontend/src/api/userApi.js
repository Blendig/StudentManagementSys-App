import axios from "../config/axios.config";
const userApi ={
    login:(creds)=>{
       
        return axios.post()
    },
    create:(data)=>{
        return axios.post(`/Users`, data)
    },
    fetchAll:()=>{
        return axios.get(`/Users`)
    },
    fetchOne:(id)=>{
        return axios.get(`/Users/${id}`)
    },
    edit:(id,data)=>{
        return axios.put(`/Users/${id}`,data)
    },
    delete:(id)=>{
        return axios.delete(`Users/${id}`)
    }
}
export default userApi