import React from 'react'
import SettingsPersonalInfoForm from '../sections/app/setings.js/SettingsPersonalInfoForm'

export default function Settings() {
  return (
    <div>
        <SettingsPersonalInfoForm/>
    </div>
  )
}
