import React from 'react'

import PageTitle from '../components/Typography/PageTitle'

function Student() {
  return (
    <>
      <PageTitle>Student</PageTitle>
    </>
  )
}

export default Student
