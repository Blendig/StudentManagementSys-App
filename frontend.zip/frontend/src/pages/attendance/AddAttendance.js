import React from 'react'
import AddAnnouncementForm from '../../sections/app/attendance/AddAttendanceForm'

export default function AddAttendance() {
  return (
    <div>
        <AddAnnouncementForm/>
    </div>
  )
}
