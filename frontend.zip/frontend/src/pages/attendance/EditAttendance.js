import React from 'react'
import EditAttendanceForm from '../../sections/app/attendance/EditAttendanceForm'

export default function EditAttendance() {
  return (
    <div>
        <EditAttendanceForm/>
    </div>
  )
}
