import React from 'react'
import AttendanceViewer from '../../sections/app/attendance/AttendanceViewer'

export default function AttendanceDetailCard({ studentId }) {
  return (
    <div className=''>
      <AttendanceViewer />
    </div>
  )
}
