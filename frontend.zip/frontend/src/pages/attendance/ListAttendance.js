import React from 'react'
import AttendanceList from '../../sections/app/attendance/AttendanceList'

export default function ListAttendance() {
  return (
    <div>
        <AttendanceList/>
    </div>
  )
}
