import React from 'react'

export default function ViewAttendanceDetail() {
  return (
    <div className=''>
        
    </div>
  )
}
