import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import ClassroomList from '../../sections/app/classrooms/ClassroomList'

//--------------------------------------------------
export default function ListClassroom() {
  return (
    <div>
        <PageTitle>Classrooms</PageTitle>
        <ClassroomList/>
    </div>
  )
}
