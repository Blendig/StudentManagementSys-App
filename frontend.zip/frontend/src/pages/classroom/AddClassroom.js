import React from 'react'
import AddClassroomForm from '../../sections/app/classrooms/AddClassroomForm'
import PageTitle from '../../components/Typography/PageTitle'

//-----------------------------------------------
export default function AddClassroom() {
  return (
    <div>
        <PageTitle>Create Classroom</PageTitle>
        <AddClassroomForm/>
    </div>
  )
}
