import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import EditClassroomForm from '../../sections/app/classrooms/EditClassroomForm'

export default function EditClassroom() {
  return (
    <div>
        
        <EditClassroomForm/>
    </div>
  )
}
