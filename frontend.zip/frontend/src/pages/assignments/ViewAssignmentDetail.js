import React from 'react'
import ViewAssignment from '../../sections/app/assignments/ViewAssignment'

export default function ViewAssignmentDetail() {
  return (
    <div>
        <ViewAssignment/>
    </div>
  )
}
