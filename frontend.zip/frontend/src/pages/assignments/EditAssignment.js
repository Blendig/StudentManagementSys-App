import React from 'react'
import EditAssignmentForm from '../../sections/app/assignments/EditAssignmentForm'

export default function EditAssignment() {
  return (
    <div>
        <EditAssignmentForm/>
    </div>
  )
}
