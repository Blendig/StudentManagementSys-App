import React from 'react'
import AddAssignmentForm from '../../sections/app/assignments/AddAssignmentForm'

export default function AddAssignment() {
  return (
    <div>
        <AddAssignmentForm/>
    </div>
  )
}
