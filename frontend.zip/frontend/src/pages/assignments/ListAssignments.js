import React from 'react'
import AssignmentList from '../../sections/app/assignments/AssignmentList'

export default function ListAssignments() {
  return (
    <div>
        <AssignmentList/>
    </div>
  )
}
