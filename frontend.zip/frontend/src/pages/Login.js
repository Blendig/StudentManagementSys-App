import React from 'react'
import { useFormik, Form, FormikProvider } from 'formik';
import * as Yup from 'yup'

import ImageLight from '../assets/img/login-office.jpeg'
import ImageDark from '../assets/img/login-office-dark.jpeg'
import { GithubIcon, TwitterIcon } from '../icons'
import { Label, Input, Button } from '@windmill/react-ui'
import userApi from '../api/userApi'

function Login() {

  const validationSchema = Yup.object().shape({
    email: Yup.string().email().required('Email is required'),
    password: Yup.string().required('Password is required'),

  });
  const onSubmit = async (creds) => {
    console.log(creds)
    try {
      const post = await userApi.login(creds);
      if (post) {

      }
    } catch (error) {

    }
  }
  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',

    },
    validationSchema,
    onSubmit
  });

  const { values, errors, touched, handleBlur, handleSubmit, handleChange } = formik;

  return (
    <FormikProvider value={formik}>
      <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
        <div className="flex items-center min-h-screen p-6 bg-gray-50 dark:bg-gray-900">
          <div className="flex-1 h-full max-w-4xl mx-auto overflow-hidden bg-white rounded-lg shadow-xl dark:bg-gray-800">
            <div className="flex flex-col overflow-y-auto md:flex-row">
              <div className="h-32 md:h-auto md:w-1/2">
                <img
                  aria-hidden="true"
                  className="object-cover w-full h-full dark:hidden"
                  src={ImageLight}
                  alt="Office"
                />
                <img
                  aria-hidden="true"
                  className="hidden object-cover w-full h-full dark:block"
                  src={ImageDark}
                  alt="Office"
                />
              </div>

              <main className="flex items-center justify-center p-6 sm:p-12 md:w-1/2">

                <div className="w-full">
                  <h1 className="mb-4 text-xl font-semibold text-gray-700 dark:text-gray-200">Login</h1>
                  <Label>
                    <span>Email</span>
                    <Input className="mt-1" type="email"
                      value={values.email}
                      onChange={handleChange}
                      name='email'
                      placeholder="john@doe.com" />
                  </Label>

                  <Label className="mt-4">
                    <span>Password</span>
                    <Input className="mt-1" type="password" name='password' onChange={handleChange} value={values.password} placeholder="***************" />
                  </Label>

                  <Button className="mt-4" block type='submit' to="/app">
                    Log in
                  </Button>

                  <hr className="my-8" />
                  <div style={{ display: 'none' }}>
                    <Button block layout="outline">
                      <GithubIcon className="w-4 h-4 mr-2" aria-hidden="true" />
                      Github
                    </Button>
                    <Button className="mt-4" block layout="outline">
                      <TwitterIcon className="w-4 h-4 mr-2" aria-hidden="true" />
                      Twitter
                    </Button>
                  </div>

                </div>

              </main>

            </div>
          </div>
        </div>
      </Form>
    </FormikProvider>
  )
}

export default Login
