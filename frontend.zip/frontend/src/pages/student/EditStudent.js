import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import EditStudentForm from '../../sections/app/student/EditStudent'

export default function EditStudent() {
  return (
    <div>
        <PageTitle>Student</PageTitle>
        <EditStudentForm/>
    </div>
  )
}
