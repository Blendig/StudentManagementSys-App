import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import StudentList from '../../sections/app/student/StudentList'

//-------------------------------------------------

export default function ListStudents() {
  return (
    <div>
        <PageTitle>Students</PageTitle>
        <StudentList/>
    </div>
  )
}
