import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import AddStudentForm from '../../sections/app/student/AddStudentForm'

export default function AddStudent() {
  return (
    <div>
        <PageTitle>Add student</PageTitle>
        <AddStudentForm/>
    </div>
  )
}
