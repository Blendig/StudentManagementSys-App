import React from 'react'
import AnnouncementList from '../../sections/app/announcements/AnnouncementList'

export default function ListAnnouncement() {
  return (
    <div>
        <AnnouncementList/>
    </div>
  )
}
