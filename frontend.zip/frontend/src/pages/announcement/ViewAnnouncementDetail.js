import React from 'react'
import ViewAnnouncement from '../../sections/app/announcements/ViewAnnouncement'

export default function ViewAnnouncementDetail() {
  return (
    <div>
        <ViewAnnouncement/>
    </div>
  )
}
