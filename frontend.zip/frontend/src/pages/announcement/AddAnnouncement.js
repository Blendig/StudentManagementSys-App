import React from 'react'
import AddAnnouncementForm from '../../sections/app/announcements/AddAnnouncementForm'

export default function AddAnnouncement() {
  return (
    <div>
        <AddAnnouncementForm/>
    </div>
  )
}
