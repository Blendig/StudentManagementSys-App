import React from 'react'
import EditAnnouncementForm from '../../sections/app/announcements/EditAnnouncementForm'

export default function EditAnnouncement() {
  return (
    <div>
      <EditAnnouncementForm/>
    </div>
  )
}
