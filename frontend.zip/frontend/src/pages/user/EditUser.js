import React from 'react';
import EditUserForm from '../../sections/app/users/EditUserForm';
//----------------------------------------------------------
export default function EditUser() {
    return(
        <div className=''>
            <EditUserForm/>
        </div>
    )
}