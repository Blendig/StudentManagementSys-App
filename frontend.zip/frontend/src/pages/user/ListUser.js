import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import UserList from '../../sections/app/users/UserList'

export default function ListUser() {
  return (
    <div>
        <PageTitle>Users</PageTitle>
        <UserList/>
    </div>
  )
}
