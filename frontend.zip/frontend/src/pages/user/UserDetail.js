import React from 'react';
import UserDetailCard from "../../sections/app/users/UserDetailCard";

export default function UserDetail(){
    return(
        <div className="">
            <UserDetailCard/>
        </div>
    )
}