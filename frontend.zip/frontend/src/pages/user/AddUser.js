import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import AddUserForm from '../../sections/app/users/AddUserForm'

export default function AddUser() {
  return (
    <div>
        <PageTitle>Users</PageTitle>
        <AddUserForm/>
    </div>
  )
}
