import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import CourseList from '../../sections/app/courses/CourseList'

//-----------------------------------
export default function ListCourse() {
  return (
    <div>
        <PageTitle>Courses</PageTitle>
        <CourseList/>
    </div>
  )
}
