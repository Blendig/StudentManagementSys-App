import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import AddCourseForm from '../../sections/app/courses/AddCourseForm'

export default function AddCourse() {
  return (
    <div>
        <PageTitle>Courses</PageTitle>
        <AddCourseForm/>
    </div>
  )
}
