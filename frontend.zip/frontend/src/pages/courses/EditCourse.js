import React from 'react'
import PageTitle from '../../components/Typography/PageTitle'
import EditCourseForm from '../../sections/app/courses/EditCourseForm'


//------------------------------------------
export default function EditCourse() {
  return (
    <div>
        <PageTitle>Courses</PageTitle>
        <EditCourseForm/>
    </div>
  )
}
