import React from 'react'
import ViewCourse from '../../sections/app/courses/ViewCourse'

export default function ViewCourseDetail() {
  return (
    <div>
        <ViewCourse/>

    </div>
  )
}
