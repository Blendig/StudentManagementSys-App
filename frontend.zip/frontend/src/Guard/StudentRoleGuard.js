import React from 'react'
import { useAuth } from '../../hooks/use-auth';
//------------------------------------------------------
export default function StudentRoleGuard({ children }) {
    const { user } = useAuth();

    const res = () => {
        return (
            <>{user.role=== 2 &&children}</>
        )
    }
    return { res }
}
