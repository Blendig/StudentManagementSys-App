import React from 'react'

export default function AdminRoleGuard() {
  return (
    <div>AdminRoleGuard</div>
  )
}
