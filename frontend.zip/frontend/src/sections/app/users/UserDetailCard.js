import React from "react";
import SectionTitle from "../../../components/Typography/SectionTitle";

//-----------------------------------------------
export default function UserDetailCard({user}) {
    return (
        <div className='mt-5'>
            <SectionTitle>User Information</SectionTitle>
            <div className="mt-10">
                <div className="">
                    

                </div>
            </div>
            
        </div>
    )
}