import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'
import userApi from '../../../api/userApi';
import * as Yup from 'yup';
import { useFormik, FormikProvider, Form } from 'formik';

//-----------------------------------------------------
export default function AddUserForm() {
    const [avatar, setAvatar] = useState(null);

    async function onSubmit(newUser) {
        if (newUser.password === newUser.confirmPassword) {
            try {
                const create = userApi.create();
                if (create) {
                    alert('User created successfully !')
                }
            } catch (error) {
                alert('Operation failed !')
            }
        } else {
            alert('Sorry your password do not match')
        }
    }

    function processFileupload(e) {
        const accepted = ['image/png', 'image/jpg', 'image/gif', 'image/jpeg']
        const _file = e.target.files[0];
        if (_file&&_file) {
            if (accepted.includes(_file.type)) {
                setAvatar(_file);
            } else {
                alert('Invalid file type selected')
            }
        }
    }

    const validationSchema = Yup.object().shape({
        firstName: Yup.string().min(2, 'Value length invalid').required('Required field'),
        lastName: Yup.string().min(2, 'Value length invalid').required('Required field'),
        email: Yup.string().email('Please enter a valid email').required('Required field'),
        gender: Yup.string().oneOf(['male', 'female'], 'Select a value').required('Required field'),
        dob: Yup.string().required('Required field'),
        password: Yup.string().
            min(6, 'Enter a minimum of characters')
            .required('Reqiured field'),
        confirmPassword: Yup.string().
            min(6, 'Enter a minimum of characters')
            .required('Reqiured field')

    })
    const formik = useFormik({
        initialValues: {
            firstName: '',
            lastName: '',
            email: '',
            gender: '',
            dob: '',
            password: '',
            confirmPassword: '',
            address: '',
            country:'',
            city:'',
            address:''


        },
        validationSchema,
        onSubmit
    })
    const { values, errors, touched, handleChange, handleSubmit, handleBlur } = formik;

    return (
        <div>
            <SectionTitle>Create User</SectionTitle>
            <FormikProvider value={formik}>
                <Form autoComplete="off" noValidate onSubmit={handleSubmit}>


                    <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                        <div className='flex'>
                            <Label className="my-5 mr-5 w-full">
                                <span>First Name</span>
                                <Input
                                    className="mt-2"
                                    placeholder="firstname"
                                    value={values.firstName}
                                    onChange={handleChange}

                                />
                            </Label>
                            <Label className="my-5 w-full">
                                <span>Last Name</span>
                                <Input
                                    className="mt-2"
                                    placeholder="lastName"
                                    value={values.lastName}
                                    onChange={handleChange}

                                />                            </Label>
                        </div>
                        <div className="flex">
                            <Label className="my-5 w-full">
                                <span>Gender</span>
                                <Select className='mt-2' name='classroom'>
                                    <option value=''>select</option>
                                    {
                                        ['male', 'female'].map((c, _index) => (
                                            <option key={_index} value={c}>{c}</option>
                                        ))
                                    }
                                </Select>
                            </Label>
                        </div>

                        <div className="flex mt-2">
                            <Label className="my-5 w-full mr-5">
                                <span>Email</span>
                                <Input className="mt-2"
                                    value={values.email}
                                    onChange={handleChange}
                                    type='email'
                                    placeholder="example@mail.com" />
                            </Label>
                            <Label className="my-5 w-full mr-5">
                                <span>Date of Birth</span>
                                <Input
                                    className="mt-2"
                                    type='date'
                                    value={values.dob}
                                    onChange={handleChange}
                                    placeholder="example@mail.com"
                                />
                            </Label>
                        </div>
                        <div className='mt-2 flex'>
                            <Label className="my-5 w-full mr-5">
                                <span>Country</span>
                    
                                <Select className='mt-2' name='country' onChange={handleChange} value={values.country}>
                                    <option value=''>select</option>
                                    {
                                        ['Albania', 'England'].map((c, _index) => (
                                            <option key={_index} value={c}>{c}</option>
                                        ))
                                    }
                                </Select>
                            </Label>
                            <Label className="my-5 w-full mr-5">
                                <span>City</span>
                                <Select className='mt-2' name='city' value={values.city} onChange={handleChange}>
                                    <option value=''>select</option>
                                    {
                                        ['city 1', 'city 2'].map((c, _index) => (
                                            <option key={_index} value={c}>{c}</option>
                                        ))
                                    }
                                </Select>
                            </Label>
                            <Label className="my-5 w-full mr-5">
                                <span>Address (optional)</span>
                                <Input
                                    className="mt-2"
                                    type='text'
                                    value={values.address}
                                    onChange={handleChange}
                                    placeholder="Enter address"
                                />
                            </Label>
                        </div>
                        <div className='flex mt-2'>
                            <Label className="my-5 w-full mr-5">
                                <span>Password</span>
                                <Input
                                    className="mt-2"
                                    type='password'
                                    placeholder="Enter your password" />
                            </Label>
                            <Label className="my-5 w-full mr-5">
                                <span>Confirm Password</span>
                                <Input className="mt-2"
                                    type='password'
                                    placeholder="Confirm password" />
                            </Label>
                        </div>

                        <div className='my-10'>
                            <Label className="my-5 w-full">

                                <Input
                                    type='file'
                                    name='avatar'
                                    id='avatar'
                                    onChange={processFileupload}
                                    accept='png||jpg||gif||jpeg'
                                    hidden
                                    style={{ display: 'none' }}
                                />
                                <Button>
                                    <Label htmlFor='avatar'> Upload Photo</Label>
                                </Button>
                            </Label>
                            <div className='h-100 w-100 objectfit-cover'>
                                {avatar !== null && <img src={URL.createObjectURL(avatar)} alt='add avatar' className='h-100 w-100' height='200px' width='200px' />}
                            </div>
                        </div>

                        <div className='my-10 flex flex-right' >
                            <div>
                                <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                            </div>
                        </div>



                    </div>
                </Form>
            </FormikProvider>
        </div>
    )
}
