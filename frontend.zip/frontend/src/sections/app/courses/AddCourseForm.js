import React from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'

//-----------------------------------------------------
export default function AddCourseForm() {
    return (
        <div>
            <SectionTitle>Create Course</SectionTitle>

            <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                <div className='flex'>
                    <Label className="my-5 mr-5 w-full">
                        <span>Course Name</span>
                        <Input className="mt-2" placeholder="Course name" />
                    </Label>
                </div>

                <div className="flex mt-2">
                    <Label className="my-5 w-full mr-5">
                        <span>Duration</span>
                        <Input className="mt-2" type='number' placeholder="Duration" />
                    </Label>
                </div>
                <div className="flex mt-2">
                    <Label className="mt-4 w-full">
                        <span>Description</span>
                        <Textarea className="mt-1 w-full" rows="3" placeholder="Enter course description." />
                    </Label>
                </div>

                <div className='my-10 flex flex-right' >
                    <div>
                        <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                    </div>
                </div>



            </div>

        </div>
    )
}
