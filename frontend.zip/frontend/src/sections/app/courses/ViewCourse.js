import React, { useState, useEffect } from 'react'
import courseApi from '../../../api/courseApi'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { useParams } from 'react-router-dom'
import { Label } from '@windmill/react-ui'
export default function ViewCourse() {
    const params = useParams();
    const [course, setCourse] = useState(null)
    useEffect(() => {
        (
            async function () {
                const s = await courseApi.fetchOne(params.id)
                if (s) {
                    setCourse(s.data)
                }
            }
        )()

        return () => {

        }
    }, [])

    return (
        <div>
            <SectionTitle>View course</SectionTitle>
            <Label>{course && course.title || 'Not defined'} </Label>
            {course && course &&
                <div className=''>

                    <div> {course.description} </div>

                    <Label><h4>Course Materials</h4></Label>
                    <ul>
                       {
                        course.attachments.map((attachment,i)=>
                        
                        (
                            <>
                            <li key={i}><a href={attachment} download>{attachment.name}</a></li>
                            </>
                        ))
                       }
                    </ul>
                </div>
            }
        </div>
    )
}
