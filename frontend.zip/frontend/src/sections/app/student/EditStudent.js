import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'
import studentApi from '../../../api/studentApi'
import * as Yup from 'yup';
import { useFormik, FormikProvider, Form } from 'formik';
import classroomApi from '../../../api/classroomApi';
import courseApi from '../../../api/courseApi';
import PropTypes from 'prop-types'
//-----------------------------------------------------
EditStudentForm.propTypes={
    rowId:PropTypes.string.isRequired
}
export default function EditStudentForm({rowId}) {

    const [classrooms, setClassrooms] = useState([])

    const [courses, setCourses] = useState([])

    const [avatar, setAvatar] = useState(null);

    const [data,setData] = useState(null)
    
    //useEffect
    useEffect(() => {
        (
            async function () {
                const c = await studentApi.fetchOne(rowId);
                setData(c.data)
            }
        )();
        (
            async function () {
                const c = await classroomApi.fetchAll();
                setClassrooms(c.data)
            }
        )();
        (
            async function () {
                const c = await courseApi.fetchAll();
                setCourses(c.data)
            }
        )();
        return () => { }
    }, [])
    async function onSubmit(vals) {
        try {
            const create = studentApi.create(vals);
            if (create) {
                alert('Student created successfully !')
            }
        } catch (error) {
            alert('Operation failed !')

        }

    }
    function processFileupload(e) {
        const accepted = ['image/png', 'image/jpg', 'image/gif', 'image/jpeg']
        const _file = e.target.files[0];
        if (_file) {
            if (accepted.includes(_file.type)) {
                setAvatar(_file);
            } else {
                alert('Invalid file type selected')
            }

        }

    }
    const validationSchema = Yup.object().shape({
        firstName: Yup.string().min(2, 'Value length invalid').required('Required field'),
        lastName: Yup.string().min(2, 'Value length invalid').required('Required field'),
        email: Yup.string().email('Please enter a valid email').required('Required field'),
        gender: Yup.string().oneOf(['male', 'female'], 'Select a value').required('Required field'),
        dob: Yup.string().required('Required field'),
        classroom: Yup.string().oneOf(classrooms, 'Select a value').required('Required field'),
        courses: Yup.string().oneOf(courses, 'Select a value').required('Required field'),
    })
    const formik = useFormik({
        initialValues: {
            firstName: data?.firstName,
            lastName: data?.lastName,
            email: data?.email,
            gender: data?.gender,
            dob: data?.dob,
            classroom: data?.classroom,
            courses: data?.courses,

        },
        validationSchema,
        onSubmit
    })
    const { values, errors, touched, handleChange, handleSubmit, handleBlur } = formik;

    return (
        <div>
            <SectionTitle>Create Student</SectionTitle>
            <FormikProvider value={formik}>
                <Form autoComplete="off" noValidate onSubmit={handleSubmit}>

                    <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                        <div className='flex'>
                            <Label className="my-5 mr-5 w-full">
                                <span>First Name</span>
                                <Input
                                    className="mt-2"
                                    placeholder="firstname"
                                    value={values.firstName}
                                    onChange={handleChange}

                                />
                            </Label>
                            <Label className="my-5 w-full">
                                <span>Last Name</span>
                                <Input className="mt-2"
                                    value={values.lastName}
                                    onChange={handleChange}
                                    placeholder="lastname" />
                            </Label>
                        </div>
                        <div className="flex">
                            <Label className="my-5 w-full">
                                <span>Gender</span>
                                <Select className='mt-2' name='gender' value={values.gender}>
                                    <option value=''>select</option>
                                    {
                                        ['male', 'female'].map((c, _index) => (
                                            <option key={_index} value={c}>{c}</option>
                                        ))
                                    }
                                </Select>
                            </Label>

                        </div>
                        <div className="flex mt-2">
                            <Label className="my-5 w-full mr-5">
                                <span>Email</span>
                                <Input className="mt-2"
                                    value={values.email}
                                    onChange={handleChange}
                                    type='email'
                                    placeholder="example@mail.com" />
                            </Label>
                            <Label className="my-5 w-full mr-5">
                                <span>Date of Birth</span>
                                <Input
                                    className="mt-2"
                                    type='date'
                                    value={values.dob}
                                    onChange={handleChange}
                                    placeholder="example@mail.com"
                                />
                            </Label>

                        </div>
                        <div className='mt-2'>
                            <Label className="my-5 w-full">
                                <span>Classroom</span>
                                <Select className='mt-2'
                                    value={[values.classroom]}
                                    onChange={handleChange}
                                    name='classroom'>
                                    <option>select</option>
                                    {
                                        [1, 2, 3].map((c, _index) => (
                                            <option key={_index} value={c}>{c}</option>
                                        ))
                                    }
                                </Select>
                            </Label>
                        </div>

                        <div className='mt-2'>
                            <Label className="my-5 w-full">
                                <span>Courses</span>
                                <Select className='mt-2'
                                    value={[values.courses]}
                                    onChange={handleChange}
                                    name='courses'
                                    multiple>
                                    <option value=''>select</option>
                                    {
                                        ['course 1', 'course 2', 'course 3'].map((c, _index) => (
                                            <option key={_index} value={c}>{c}</option>
                                        ))
                                    }
                                </Select>
                            </Label>
                        </div>
                        <div className='my-10'>
                            <Label className="my-5 w-full">

                                <Input
                                    type='file'
                                    name='avatar'
                                    id='avatar'
                                    onChange={processFileupload}
                                    accept='png||jpg||gif||jpeg'
                                    hidden
                                    style={{ display: 'none' }}
                                />
                                <Button>
                                    <Label htmlFor='avatar'> Upload Photo</Label>
                                </Button>
                            </Label>
                            <div className='h-100 w-100 objectfit-cover'>
                                {avatar !== null && <img src={URL.createObjectURL(avatar)} alt='add avatar' className='h-100 w-100' height='200px' width='200px' />}
                            </div>
                        </div>

                        <div className='my-10 flex flex-right' >
                            <div>
                                <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                            </div>
                        </div>



                    </div>

                </Form>
            </FormikProvider>
        </div>
    )
}
