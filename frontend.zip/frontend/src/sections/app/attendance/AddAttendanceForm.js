import React, { useState,useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, HelperText, Checkbox, Label, Select, Textarea, Button } from '@windmill/react-ui'
import classrooms from '../../../utils/demo/classrooms'
import { useFormik, Form, FormikProvider } from 'formik';
import * as Yup from 'yup'
import AppModal from '../../../components/AppModal';
import tableData from '../../../utils/demo/tableData';
import classroomApi from '../../../api/classroomApi';
import studentApi from '../../../api/studentApi';
//-----------------------------------------------------
export default function AddAttendanceForm() {
    //show list of students in a class and check mark the status
    const [students, setStudents] = useState([]);

    const [selectClass, setSelectClass] = useState('');

    const [isModalOpen, setIsModalOpen] = useState(true)





    //useEffect
    useEffect(() => {
      (
        async function() {
            const r = await studentApi.fetchAll();
            const c = await classroomApi.fetchAll();
            
            try {
                if(r&&c){

                }
                
            } catch (error) {
                alert("Operation failed")
            }
           
        }
      )()
    
      return () => {
        
      }
    }, [])
    

    function openModal() {
        setIsModalOpen(true)
    }

    function closeModal() {
        setIsModalOpen(false)
    }

    
    const acceptAction = async () => {
        if (true) {
            //api call to perform delete action
            closeModal()
            try {
               
            } catch (error) {
                alert('Operation failed !')

            }
        }
    } 

    const validationSchema = Yup.object().shape({
        classroom: Yup.string().required('Classroom is required'),
        student: Yup.string().required('Student name is required'),
        attendanceDate: Yup.string().required('Attendance date is required'),
        status: Yup.string().required('Attendance status is required')
    });
    const onSubmit = () => {

    }
    const formik = useFormik({
        initialValues: {
            classroom: '',
            student: '',
            attendanceDate: '',
            status: '',
        },
        validationSchema,
        onSubmit
    });

    const handleClassChange=(e)=>{
        setSelectClass(e.target.value)
    }

    const { values, errors, touched, handleBlur, handleSubmit, handleChange } = formik;

    return (
        <div>
            <SectionTitle>Add Attendance</SectionTitle>

            <FormikProvider value={formik}>
                <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
                    <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                       
                        <div className='flex'>
                        <Label className='my-5 mr-5 w-full'>
                            <span>Date</span>
                            <Input className="mt-2" type='date' name='attendanceDate' />
                        </Label>
                            <Label className="my-5 w-full">
                                <span>Class</span>

                                <Select
                                    className="mt-2"
                                    name='audience'

                                    value={values.audience}
                                    helpertext={touched.audience && errors.audience}
                                    onChange={handleClassChange}

                                >
                                    <option value=''></option>
                                    {classrooms.map((c, i) => (
                                        <option value={c.name} key={i}>{c.name}</option>
                                    ))}
                                </Select>
                            </Label>

                        </div>
                        {/* pop modal with student list in selected class */}
                        {selectClass&&<AppModal
                            open={isModalOpen}
                            close={closeModal}
                            acceptBtnText='Save'
                            cancelBtnText='Cancel'
                            header='Attendance Sheet'
                            func={acceptAction}
                        >
                            <>
                                <p>3/02/2023</p>
                                <div className='max-h-300' style={{ maxHeight: '50vh', overflowY: 'scroll' }}>

                                    <div className='mt-10'>
                                        {
                                            tableData && tableData.map((student, i) => {
                                                const { id,name, firstName, lastName } = student;
                                                return (
                                                    <div key={i} className='my-4 cursor-pointer'>
                                                        <div>

                                                            <p><Input type='checkbox' className='mr-4 ml-2 w-5 h-5 cursor-pointer' value={values.status} data-student={id}/> {`${name}`}  </p>
                                                        </div>
                                                    </div>
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                            </>
                        </AppModal>}
                        <div className='my-10 flex flex-right' >
                            <div>
                                <Button type='submit' className='' style={{ float: 'right' }}>Done</Button>
                            </div>
                        </div>



                    </div>
                </Form>
            </FormikProvider>
        </div>
    )
}
