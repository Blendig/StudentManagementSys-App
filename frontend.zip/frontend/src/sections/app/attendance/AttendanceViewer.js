import React from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle';
import tableData from '../../../utils/demo/tableData';
import { Input, Label } from '@windmill/react-ui'

export default function AttendanceViewer({ data }) {
    //get list of attendance

    return (
        <div>
            <SectionTitle>Attendance Detail</SectionTitle>
            <>
                <Label className='pb-1'>
                    <p>3/02/2023</p>
                </Label>
                <div className='w-100 pt-5 pb-7' style={{ width: 200 }}>
                    <Label >
                        <span >Select date</span>
                       
                        <Input type='date' name='attendanceDate' className='w-full mt-2' />
                    </Label>
                </div>
                <div className='max-h-300' style={{ maxHeight: '80vh', overflowY: 'scroll' }}>

                    <div className='mt-10'>
                        {
                            tableData && tableData.map((student, i) => {
                                const { id, status, name, firstName, lastName } = student;
                                return (
                                    <div key={i} className='my-4 cursor-pointer'>
                                        <div>

                                            <Label><input
                                                type='checkbox'
                                                className='mr-4 ml-2 w-5 h-5 cursor-pointer'
                                                disabled={true}
                                                value={status}
                                                data-student={id}
                                            />
                                                {`${name}`}
                                            </Label>
                                        </div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </>
        </div>
    )
}
