import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Link as RouterLink } from 'react-router-dom';
import {
    Table,
    TableHeader,
    TableCell,
    TableBody,
    TableRow,
    TableFooter,
    TableContainer,
    Badge,
    Avatar,
    Button,
    Pagination,
} from '@windmill/react-ui';
import { EditIcon, TrashIcon } from '../../../icons'
import attendanceData from '../../../utils/demo/attendanceData';
import response from '../../../utils/demo/attendanceData'
import attendanceApi from '../../../api/attendanceApi';
import AppModal from '../../../components/AppModal';
import { useAuth } from '../../../hooks/use-auth';
// make a copy of the data, for the second table

const response2 = response.concat([])

//----------------------------------------------
export default function AttendanceList() {
    const { user } = useAuth()
    // setup pages control for every table
    const [pageTable1, setPageTable1] = useState(1)
    const [pageTable2, setPageTable2] = useState(1)

    // setup data for every table
    const [dataTable1, setDataTable1] = useState([])
    const [dataTable2, setDataTable2] = useState([])


    const [isModalOpen, setIsModalOpen] = useState(false)
    const [selectedRow, setSelectedRow] = useState(null)

    function openModal(rowId) {
        setIsModalOpen(true);
        setSelectedRow(rowId)

    }

    function closeModal() {
        setIsModalOpen(false)
    }

    // pagination setup
    const resultsPerPage = 10
    const totalResults = response.length

    // pagination change control
    function onPageChangeTable1(p) {
        setPageTable1(p)
    }

    // pagination change control
    function onPageChangeTable2(p) {
        setPageTable2(p)
    }

    // on page change, load new sliced data
    // here you would make another server request for new data
    useEffect(() => {
        setDataTable1(response.slice((pageTable1 - 1) * resultsPerPage, pageTable1 * resultsPerPage))
    }, [pageTable1])

    // on page change, load new sliced data
    // here you would make another server request for new data
    useEffect(() => {
        (
            async function () {

                try {
                    const s = await attendanceApi.fetchAll();
                    if (s) {

                    }
                } catch (error) {

                }
            }
        )()
        setDataTable2(response2.slice((pageTable2 - 1) * resultsPerPage, pageTable2 * resultsPerPage))
    }, [pageTable2])

    const acceptAction = async () => {
        if (selectedRow !== null) {
            //api call to perform delete action
            closeModal()
            try {
                const remove = await attendanceApi.delete(selectedRow)
                if (remove) {
                    const i = [].findIndex(l => l.id === selectedRow);
                    [].splice(i, 1)
                }
            } catch (error) {
                alert('Could not delete item !')

            }
        }
    }
    const renderAdmin = (
        <>
            <SectionTitle>Attendance list</SectionTitle>
            <AppModal
                header='Delete this user'
                open={isModalOpen}
                close={closeModal}
                func={acceptAction}

            >
                <div>
                    Proceed to delete this row
                </div>

            </AppModal>
            {/* GROUP BY CLASSROOMS */}

            <TableContainer className="mb-8">
                <Table>

                    <TableBody>
                        {dataTable2.map((attendance, i) => (
                            <TableRow key={i}>
                                <TableCell>
                                    <div className="flex items-center text-sm">
                                        <div>
                                            <p className="font-semibold">{attendance.student.name}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex items-center text-sm">
                                        <div>
                                            <p className="font-semibold">{attendance.classroom}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className='my-10'>
                                        <Button>
                                            <RouterLink to={`/app/attendance/${attendance.student.id}`}>
                                                View attendance
                                            </RouterLink>

                                        </Button>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="flex items-center space-x-4">
                                        <RouterLink to={`/app/attendance/edit/${attendance.id}`}>


                                            <Button layout="link" size="icon" aria-label="Edit">
                                                <EditIcon className="w-5 h-5" aria-hidden="true" />
                                            </Button>
                                        </RouterLink>



                                        <Button layout="link" size="icon" aria-label="Delete" onClick={openModal.bind(this, attendance.id)}>
                                            <TrashIcon className="w-5 h-5" aria-hidden="true" />
                                        </Button>

                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <TableFooter>
                    <Pagination
                        totalResults={totalResults}
                        resultsPerPage={resultsPerPage}
                        onChange={onPageChangeTable2}
                        label="Table navigation"
                    />
                </TableFooter>
            </TableContainer>
        </>
    )
    const renderStudent = (
        <>
            <SectionTitle>Attendance list</SectionTitle>

            {/* GROUP BY CLASSROOMS */}

            <TableContainer className="mb-8">
                <Table>

                    <TableBody>
                        {dataTable2.map((attendance, i) => (
                            <TableRow key={i}>
                                <TableCell>
                                    <div className="flex items-center text-sm">
                                        <div>
                                            <p className="font-semibold">{attendance.student.name}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex items-center text-sm">
                                        <div>
                                            <p className="font-semibold">{attendance.classroom}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className='my-10'>
                                        <Button>
                                            <RouterLink to={`/app/attendance/${attendance.student.id}`}>
                                                View attendance
                                            </RouterLink>

                                        </Button>
                                    </div>
                                </TableCell>

                               
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <TableFooter>
                    <Pagination
                        totalResults={totalResults}
                        resultsPerPage={resultsPerPage}
                        onChange={onPageChangeTable2}
                        label="Table navigation"
                    />
                </TableFooter>
            </TableContainer>
        </>
    )
    return (
        <>
            {user && user.role === 1 && renderAdmin}
            {user && user.role === 2 && renderStudent}
        </>
    )
}
