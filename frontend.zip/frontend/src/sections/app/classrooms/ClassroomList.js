import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import {Link as RouterLink} from 'react-router-dom'
import {
    Table,
    TableHeader,
    TableCell,
    TableBody,
    TableRow,
    TableFooter,
    TableContainer,
    Badge,
    Avatar,
    Button,
    Pagination,
} from '@windmill/react-ui';
import { EditIcon, TrashIcon } from '../../../icons'

import response from '../../../utils/demo/classrooms'
// make a copy of the data, for the second table

const response2 = response.concat([])

//----------------------------------------------
export default function ClassroomList() {
    // setup pages control for every table
    const [pageTable1, setPageTable1] = useState(1)
    const [pageTable2, setPageTable2] = useState(1)

    // setup data for every table
    const [dataTable1, setDataTable1] = useState([])
    const [dataTable2, setDataTable2] = useState([])

    // pagination setup
    const resultsPerPage = 10
    const totalResults = response.length

    // pagination change control
    function onPageChangeTable1(p) {
        setPageTable1(p)
    }

    // pagination change control
    function onPageChangeTable2(p) {
        setPageTable2(p)
    }

    // on page change, load new sliced data
    // here you would make another server request for new data
    useEffect(() => {
        setDataTable1(response.slice((pageTable1 - 1) * resultsPerPage, pageTable1 * resultsPerPage))
    }, [pageTable1])

    // on page change, load new sliced data
    // here you would make another server request for new data
    useEffect(() => {
        setDataTable2(response2.slice((pageTable2 - 1) * resultsPerPage, pageTable2 * resultsPerPage))
    }, [pageTable2])

    return (
        <>
            <SectionTitle>Classroom list</SectionTitle>
            <TableContainer className="mb-8">
                <Table>
                   
                    <TableBody>
                        {dataTable2.map((classroom, i) => (
                            <TableRow key={i}>
                                <TableCell>
                                    <div className="flex items-center text-sm">
                                        <div>
                                            <p className="font-semibold">{classroom.name}</p>
                                            <p className="text-xs text-gray-600 dark:text-gray-400">{classroom.size}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex items-center text-sm">
                                        <div>
                                            <p className="font-semibold">{classroom.size}</p>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <Badge type={classroom.status}>{classroom.status}</Badge>
                                </TableCell>
                            
                                <TableCell>
                                    <div className="flex items-center space-x-4">
                                      <RouterLink to={`/app/classroom/edit/${classroom.id}`}>
                                        <Button layout="link" size="icon" aria-label="Edit">
                                            <EditIcon className="w-5 h-5" aria-hidden="true" />
                                        </Button>
                                        </RouterLink>
                                        <Button layout="link" size="icon" aria-label="Delete">
                                            <TrashIcon className="w-5 h-5" aria-hidden="true" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <TableFooter>
                    <Pagination
                        totalResults={totalResults}
                        resultsPerPage={resultsPerPage}
                        onChange={onPageChangeTable2}
                        label="Table navigation"
                    />
                </TableFooter>
            </TableContainer>
        </>
    )
}
