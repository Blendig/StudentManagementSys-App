import React from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'
import * as Yup from 'yup';
import { useFormik, FormikProvider, Form } from 'formik';
import classroomApi from '../../../api/classroomApi';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
//-----------------------------------------------------
export default function EditClassroomForm() {
    async function onSubmit(vals) {
        console.log(vals)
        try {
            const create =await classroomApi.create(vals);
            if (create) {
                alert('Class created successfully !')
            }
        } catch (error) {
            alert('Operation failed !')
        }
    }

    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Required field'),
        size: Yup.number().required('Required field'),
    })
    const formik = useFormik({
        initialValues: {
            name: '',
            size: '',
            rules: ''
        },
        validationSchema,
        onSubmit
    })
    const { values, errors, touched, handleChange, handleSubmit, handleBlur } = formik;

    return (
        <div>
            <SectionTitle>Edit classroom detail</SectionTitle>

            <FormikProvider value={formik}>
                <Form autoComplete="off" noValidate onSubmit={handleSubmit}>

                    <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                        <div className='flex'>
                            <Label className="my-5 mr-5 w-full">
                                <span>Class Name</span>
                                <Input 
                                className="mt-2" 
                                name='name'
                                value={values.name}
                                onChange={handleChange}
                                placeholder="Class name" />
                            </Label>
                        </div>

                        <div className="flex mt-2">
                            <Label className="my-5 w-full mr-5">
                                <span>Size</span>
                                <Input className="mt-2"
                                 type='number' 
                                 name='size'
                                 value={values.size}
                                 onChange={handleChange}
                                 placeholder="Classroom size" />
                            </Label>
                        </div>
                        <div className="flex mt-2">
                            <Label className="mt-4 w-full">
                                <span>Rules</span>
                                <ReactQuill className="mt-2" theme="snow" name='rules' value={values.rules} onChange={handleChange} />
                            </Label>
                        </div>

                        <div className='my-10 flex flex-right' >
                            <div>
                                <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                            </div>
                        </div>
                    </div>
                </Form>
            </FormikProvider>

        </div>
    )
}
