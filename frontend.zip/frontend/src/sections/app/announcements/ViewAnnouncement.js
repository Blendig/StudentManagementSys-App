import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { useParams } from 'react-router-dom'
import { Label } from '@windmill/react-ui'
import announcementApi from '../../../api/announcementApi';


export default function ViewAnnouncement() {
    const params = useParams();
    const [announcement, setAnnouncement] = useState(null)

    useEffect(() => {
        (
            async function () {
                const s = await announcementApi.fetchOne(params.id)
                if (s) {
                    setAnnouncement(s.data)
                }
            }
        )()

        return () => {

        }
    }, [])

    return (
        <div>
            <SectionTitle>View announcement</SectionTitle>
            <Label>{announcement && announcement.title || 'Not defined'} </Label>
            <Label>{announcement && announcement.duration || 'Not defined'} </Label>

            <Label>{announcement && announcement.audience || 'Not defined'} </Label>

            {announcement && announcement &&
                <div className=''>

                    <div> {announcement.description} </div>
                    <div dangerouslySetInnerHTML={announcement.description} />

                    <Label><h4>Attachments</h4></Label>
                    <ul>
                       {
                        announcement.attachments.map((attachment,i)=>
                        
                        (
                            <>
                            <li key={i}><a href={attachment} download>{attachment.name}</a></li>
                            </>
                        ))
                       }
                    </ul>
                </div>
            }
        </div>
    )
}
