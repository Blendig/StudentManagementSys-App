import React, { useState ,useEffect} from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'
import classrooms from '../../../utils/demo/classrooms';
import { useFormik, Form, FormikProvider } from 'formik';
import * as Yup from 'yup'
import studentApi from '../../../api/studentApi';

//-----------------------------------------------------
export default function EditAnnouncementForm() {
    const [value, setValue] = useState('');
    const [file, setFile] = useState(null);
    const [student,setStudents] = useState([])
    const [classrooms,setClassroom] = useState([])
    
    useEffect(() => {
      (
        async function(){
          try {
            const c = await studentApi.fetchAll()
            if(c){

            }
          } catch (error) {
            
          }

        }
      )()
    
      return () => {
        
      }
    }, [])
    
    function processFileupload(e) {
        const accepted = [
            'image/png',
            'image/jpg',
            'image/gif',
            'image/jpeg',
            'application/pdf',
            'application/docx',
            'application/xls',
            'application/xlsx',
            'text/plain'
        ]
        const _file = e.target.files[0];
        console.log(_file.type)
        if (_file) {
            if (accepted.includes(_file.type)) {
                setFile(_file);
            } else {
                alert('Invalid file type selected')
            }
        }
    }


    const onSubmit = (payload) => {
        console.log(payload)
    }
    const initialValues = {
        title: '',
        audience: '',
        description: ''

    }
    const validationSchema = Yup.object().shape({
        title: Yup.string().required('Title is required'),
        audience: Yup.string().required('Audience type is required')
    })
    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit
    });
    const { values, errors, touched, handleBlur, handleSubmit, handleChange } = formik;
    return (
        <div>
            <SectionTitle>Create Announcement/Event</SectionTitle>
            <FormikProvider value={formik}>
                <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
                    <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                        <div className="flex mt-2">
                            <Label className="my-5 w-full mr-5">
                                <span>Title</span>
                                <Input
                                    className="mt-2"
                                    type='text'
                                    name='title'
                                    helperText={touched.title && errors.title}
                                    value={values.title}
                                    onChange={handleChange}
                                />
                            </Label>
                        </div>

                        <div className='flex'>
                            <Label className="my-5 mr-5 w-full">
                                <span>Audience</span>

                                <Select
                                    className="mt-2"
                                    name='audience'
                                    
                                    value={values.audience}
                                   
                                    helperText={touched.audience && errors.audience}
                                    onChange={handleChange}

                                >
                                    <option value=''></option>
                                    <option>All users</option>
                                    <option>All students</option>
                                    <option>All admins</option>
                                    {classrooms.map((c, i) => (
                                        <option value={c.name} key={i}>{c.name}</option>
                                    ))}
                                </Select>
                            </Label>
                        </div>


                        <div className="flex mt-2">
                            <Label className="mt-4 w-full">
                                <span>Description</span>
                                <ReactQuill className="mt-2" theme="snow" name='description' value={values.description} onChange={setValue} />
                            </Label>
                        </div>

                        <div className="mt-10">
                            <Label className="my-5 w-full">

                                <Input
                                    style={{ display: 'none' }}
                                    className="mt-2"
                                    type='file'
                                    name='attachment'
                                    id='attachment'
                                    onChange={processFileupload} />
                                <Button>
                                    <Label htmlFor='attachment'> Upload attachment</Label>
                                </Button>
                            </Label>
                            <div className='h-100 w-100 objectfit-cover'>
                                {file && file !== null && file.type.split('/')[0] === 'image'
                                &&
                                    <img src={URL.createObjectURL(file)} alt='add file' className='h-100 w-100' height='200px' width='200px' />}
                                    
                                    {file && file !== null &&<p className='bg-blue-700 p-5' style={{color:'#fff'}}>{file && file.name}</p>}
                            </div>


                        </div>

                        <div className='my-10 flex flex-right' >
                            <div>
                                <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                            </div>
                        </div>
                    </div>
                </Form>
            </FormikProvider>
        </div>
    )
}
