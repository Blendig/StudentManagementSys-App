import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'
import userApi from '../../../api/userApi';
import * as Yup from 'yup';
import { useFormik, FormikProvider, Form } from 'formik';
import { useAuth } from '../../../hooks/use-auth';


//-----------------------------------------------------
//----determine the role to display

export default function SettingsPersonalInfoForm() {
    const {user} =useAuth()
    const [avatar, setAvatar] = useState(null);

    useEffect(() => {
       /* (
            async function () {
                const c = await classroomApi.fetchAll();
                setClassrooms(c.data)
            }
        )();
        (
            async function () {
                const c = await courseApi.fetchAll();
                setCourses(c.data)
            }
        )();*/
        return () => { }
    }, [])


    function processFileupload(e) {
        const accepted = ['image/png', 'image/jpg', 'image/gif', 'image/jpeg']
        const _file = e.target.files[0];
        if (_file && _file) {
            if (accepted.includes(_file.type)) {
                setAvatar(_file);
            } else {
                alert('Invalid file type selected')
            }
        }
    }

    async function onSubmit(newUser) {
        if (newUser.password === newUser.confirmPassword) {
            try {
                const create = userApi.create();
                if (create) {
                    alert('User created successfully !')
                }
            } catch (error) {
                alert('Operation failed !')
            }
        } else {
            alert('Sorry your password do not match')
        }
    }
    const validationSchema = Yup.object().shape({
        firstName: Yup.string().min(2, 'Value length invalid').required('Required field'),
        lastName: Yup.string().min(2, 'Value length invalid').required('Required field'),
        email: Yup.string().email('Please enter a valid email').required('Required field'),
        gender: Yup.string().oneOf(['male', 'female'], 'Select a value').required('Required field'),
        dob: Yup.string().required('Required field'),
        password: Yup.string().
            min(6, 'Enter a minimum of characters')
            .required('Reqiured field'),
        confirmPassword: Yup.string().
            min(6, 'Enter a minimum of characters')
            .required('Reqiured field')

    })
    const formik = useFormik({
        initialValues: {
            firstName: '',
            lastName: '',
            email: '',
            gender: '',
            dob: '',
            password: '',
            confirmPassword: '',
            address: '',
            country: '',
            city: '',
            address: ''


        },
        validationSchema,
        onSubmit
    })
    const { values, errors, touched, handleChange, handleSubmit, handleBlur } = formik;


    return (
        <div>
            <SectionTitle>Edit Personal Information</SectionTitle>

            {user&&user&&
            <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                <div className='flex'>
                    <Label className="my-5 mr-5 w-full">
                        <span>First Name</span>
                        <Input className="mt-2" disabled={user.role !== 1} placeholder="firstname" />
                    </Label>
                    <Label className="my-5 w-full">
                        <span>Last Name</span>
                        <Input className="mt-2"  disabled={user.role !== 1} placeholder="lastname" />
                    </Label>
                </div>
                <div className="flex">
                    <Label className="my-5 w-full">
                        <span>Gender</span>
                        <Select className='mt-2'  disabled={user.role !== 1} name='classroom'>
                            <option value=''>select</option>
                            {
                                ['male', 'female'].map((c, _index) => (
                                    <option key={_index} value={c}>{c}</option>
                                ))
                            }
                        </Select>
                    </Label>

                </div>
                <div className="flex mt-2">
                    <Label className="my-5 w-full mr-5">
                        <span>Email</span>
                        <Input className="mt-2" type='email' placeholder="example@mail.com" />
                    </Label>
                    <Label className="my-5 w-full mr-5">
                        <span>Date of Birth</span>
                        <Input className="mt-2"  disabled={user.role !== 1} type='date' placeholder="example@mail.com" />
                    </Label>

                </div>
                <div className='mt-2'>
                    <Label className="my-5 w-full">
                        <span>Classroom</span>
                        <Select  disabled={user.role !== 1} className='mt-2' name='classroom'>
                            <option>select</option>
                            {
                                [1, 2, 3].map((c, _index) => (
                                    <option key={_index} value={c}>{c}</option>
                                ))
                            }
                        </Select>
                    </Label>
                </div>

                <div className='mt-2'>
                    <Label className="my-5 w-full">
                        <span>Courses</span>
                        <Select className='mt-2'  disabled={user.role !== 1} name='classroom' multiple>
                            <option value=''>select</option>
                            {
                                ['course 1', 'course 2', 'course 3'].map((c, _index) => (
                                    <option key={_index} value={c}>{c}</option>
                                ))
                            }
                        </Select>
                    </Label>
                </div>
                <div className='my-10'>
                    <Label className="my-5 w-full">

                        <Input
                            type='file'
                            name='avatar'
                            id='avatar'
                            onChange={processFileupload}
                            hidden
                            style={{ display: 'none' }}
                        />
                        <Button>
                            <Label htmlFor='avatar'> Upload Photo</Label>
                        </Button>
                    </Label>
                    <div className='h-100 w-100 objectfit-cover'>
                        {avatar !== null && <img src={URL.createObjectURL(avatar)} alt='add avatar' className='h-100 w-100' height='200px' width='200px' />}
                    </div>
                </div>

                <div className='my-10 flex flex-right' >
                    <div>
                        <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                    </div>
                </div>



            </div>}

        </div>
    )
}
