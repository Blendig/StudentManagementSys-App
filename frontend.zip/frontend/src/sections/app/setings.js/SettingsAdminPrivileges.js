import React from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'

//-----------------------------------------------------
//----page for admins only to set privilages

export default function SettingsAdminPrivileges() {
    return (
        <div>
            <SectionTitle>Edit Personal Information</SectionTitle>

            <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                <div className='flex'>
                    <Label className="my-5 mr-5 w-full">
                        <span>First Name</span>
                        <Input className="mt-2" placeholder="firstname" />
                    </Label>
                    <Label className="my-5 w-full">
                        <span>Last Name</span>
                        <Input className="mt-2" placeholder="lastname" />
                    </Label>
                </div>
                <div className="flex">
                    <Label className="my-5 w-full">
                        <span>Gender</span>
                        <Select className='mt-2' name='classroom'>
                            <option value=''>select</option>
                            {
                                ['male', 'female'].map((c, _index) => (
                                    <option key={_index} value={c}>{c}</option>
                                ))
                            }
                        </Select>
                    </Label>

                </div>
                <div className="flex mt-2">
                    <Label className="my-5 w-full mr-5">
                        <span>Email</span>
                        <Input className="mt-2" type='email' placeholder="example@mail.com" />
                    </Label>
                    <Label className="my-5 w-full mr-5">
                        <span>Date of Birth</span>
                        <Input className="mt-2" type='date' placeholder="example@mail.com" />
                    </Label>

                </div>
                <div className='mt-2'>
                    <Label className="my-5 w-full">
                        <span>Classroom</span>
                        <Select className='mt-2' name='classroom'>
                            <option>select</option>
                            {
                                [1, 2, 3].map((c, _index) => (
                                    <option key={_index} value={c}>{c}</option>
                                ))
                            }
                        </Select>
                    </Label>
                </div>

                <div className='mt-2'>
                    <Label className="my-5 w-full">
                        <span>Courses</span>
                        <Select className='mt-2' name='classroom' multiple>
                            <option value=''>select</option>
                            {
                                ['course 1', 'course 2', 'course 3'].map((c, _index) => (
                                    <option key={_index} value={c}>{c}</option>
                                ))
                            }
                        </Select>
                    </Label>
                </div>
                <div className='my-10'>
                    <Label className="my-5 w-full">

                        <Input
                            type='file'
                            name='avatar'
                            id='avatar'
                            onChange={processFileupload}
                            accept='png||jpg||gif||jpeg'
                            hidden
                            style={{ display: 'none' }}
                        />
                        <Button>
                            <Label htmlFor='avatar'> Upload Photo</Label>
                        </Button>
                    </Label>
                    <div className='h-100 w-100 objectfit-cover'>
                        {avatar !== null && <img src={URL.createObjectURL(avatar)} alt='add avatar' className='h-100 w-100' height='200px' width='200px' />}
                    </div>
                </div>

                <div className='my-10 flex flex-right' >
                    <div>
                        <Button type='submit' className='' style={{ float: 'right' }}>Submit</Button>
                    </div>
                </div>



            </div>

        </div>
    )
}
