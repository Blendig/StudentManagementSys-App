import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import SectionTitle from '../../../components/Typography/SectionTitle'
import { Input, Button, HelperText, Label, Select, Textarea } from '@windmill/react-ui'
import courses from '../../../utils/demo/courses';
import classrooms from '../../../utils/demo/classrooms';
import { useFormik, Form, FormikProvider } from 'formik';
import * as Yup from 'yup'
//-----------------------------------------------------
export default function AddAssignmentForm() {
    const [value, setValue] = useState('');
    const [file, setFile] = useState(null);

    function processFileupload(e) {
        const accepted = [
            'image/png',
            'image/jpg',
            'image/gif',
            'image/jpeg',
            'application/pdf',
            'application/docx',
            'application/xls',
            'application/xlsx',
            'text/plain'
        ]
        const _file = e.target.files[0];
        console.log(_file.type)
        if (_file) {
            if (accepted.includes(_file.type)) {
                setFile(_file);
            } else {
                alert('Invalid file type selected')
            }
        }
    }

    const onSubmit = (payload) => {
        console.log(payload)
    }
    const initialValues = {
        course: '',
        audience: '',
        description: '',
        duration: ''
    }
    const validationSchema = Yup.object().shape({
        course: Yup.string().required('Course name is required'),
        audience: Yup.string().required('Audience type is required'),
        duration: Yup.string().required('Duration is required')
    })
    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit
    });
    const { values, errors, touched, handleBlur, handleSubmit, handleChange } = formik;

    return (
        <div>
            <SectionTitle>Create Assignment</SectionTitle>
            <FormikProvider value={formik}>
                <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
                    <div className="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800">
                        <div className='flex'>
                            <Label className="my-5 mr-5 w-full">
                                <span>Course Name</span>

                                <Select
                                    name='course'
                                    onChange={handleChange}
                                    value={values.course}

                                >
                                    <option value=''>select</option>
                                    {courses && courses.map((c, i) => (
                                        <option value={c.name} key={i}>{c.name}</option>
                                    ))}
                                </Select>
                            </Label>
                        </div>


                        <div className='flex'>
                            <Label className="my-5 mr-5 w-full">
                                <span>Audience</span>

                                <Select
                                    className="mt-2"
                                    name='audience'
                                    
                                    value={values.audience}
                                    helpertext={touched.audience && errors.audience}
                                    onChange={handleChange}

                                >
                                    <option value=''></option>
                                    <option>All users</option>
                                    <option>All students</option>
                                    {classrooms.map((c, i) => (
                                        <option value={c.name} key={i}>{c.name}</option>
                                    ))}
                                </Select>
                            </Label>
                        </div>

                        <div className="flex mt-2">
                            <Label className="my-5 w-full mr-5">
                                <span>Duration</span>
                                <Input
                                    className="mt-2"
                                    type='number'
                                    name='duration'
                                    placeholder="Duration" />
                            </Label>
                        </div>

                        <div className="flex mt-2">
                            <Label className="mt-4 w-full">
                                <span>Description</span>
                                <ReactQuill
                                    className="mt-2"
                                    theme="snow"
                                    value={values.description}
                                    onChange={handleChange}
                                    name='description'
                                />
                            </Label>
                        </div>

                        <div className="mt-10">
                            <Label className="my-5 w-full">

                                <Input
                                    style={{ display: 'none' }}
                                    className="mt-2"
                                    type='file'
                                    name='attachment'
                                    id='attachment'
                                    onChange={processFileupload} />
                                <Button>
                                    <Label htmlFor='attachment'> Upload attachment</Label>
                                </Button>
                            </Label>
                            <div className='h-100 w-100 objectfit-cover'>
                                {file && file !== null && file.type.split('/')[0] === 'image'
                                &&
                                    <img src={URL.createObjectURL(file)} alt='add file' className='h-100 w-100' height='200px' width='200px' />}
                                    
                                    {file && file !== null &&<p className='bg-blue-700 p-5' style={{color:'#fff'}}>{file && file.name}</p>}
                            </div>


                        </div>

                        <div className='my-10 flex flex-right' >
                            <div>
                                <Button type='submit' className='' style={{ float: 'right' }} >Submit</Button>
                            </div>
                        </div>
                    </div>
                </Form>
            </FormikProvider>
        </div>
    )
}
