import React, { useState, useEffect } from 'react'
import SectionTitle from '../../../components/Typography/SectionTitle'
import { useParams } from 'react-router-dom'
import { Label } from '@windmill/react-ui'
import assignmentApi from '../../../api/assignmentApi';


export default function ViewAssignment() {
    const params = useParams();
    const [assignment, setAssignment] = useState(null)

    useEffect(() => {
        (
            async function () {
                const s = await assignmentApi.fetchOne(params.id)
                if (s) {
                    setAssignment(s.data)
                }
            }
        )()

        return () => {

        }
    }, [])

    return (
        <div>
            <SectionTitle>View assignment</SectionTitle>
            <Label>{assignment && assignment.title || 'Not defined'} </Label>
            <Label>{assignment && assignment.duration || 'Not defined'} </Label>

            <Label>{assignment && assignment.audience || 'Not defined'} </Label>

            {assignment && assignment &&
                <div className=''>

                    <div> {assignment.description} </div>
                    <div dangerouslySetInnerHTML={assignment.description} />

                    <Label><h4>Course Materials</h4></Label>
                    <ul>
                       {
                        assignment.attachments.map((attachment,i)=>
                        
                        (
                            <>
                            <li key={i}><a href={attachment} download>{attachment.name}</a></li>
                            </>
                        ))
                       }
                    </ul>
                </div>
            }
        </div>
    )
}
